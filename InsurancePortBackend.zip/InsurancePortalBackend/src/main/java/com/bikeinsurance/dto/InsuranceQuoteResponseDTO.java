package com.bikeinsurance.dto;

public class InsuranceQuoteResponseDTO {

    private String providerName;
    private double basic;
    private double premium;

    public InsuranceQuoteResponseDTO() {}

    public InsuranceQuoteResponseDTO(String providerName, double basic, double premium) {
        this.providerName = providerName;
        this.basic = basic;
        this.premium = premium;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public double getBasic() {
        return basic;
    }

    public void setBasic(double basic) {
        this.basic = basic;
    }

    public double getPremium() {
        return premium;
    }

    public void setPremium(double premium) {
        this.premium = premium;
    }
}
