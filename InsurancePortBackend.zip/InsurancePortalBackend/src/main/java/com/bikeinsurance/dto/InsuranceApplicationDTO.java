package com.bikeinsurance.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InsuranceApplicationDTO {

    private String userId;  // Changed from Long to String
    private Long vehicleId;
    private String selectedProvider;
    private String selectedPlan;
    private Double premiumAmount;

    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getVehicleId() {
        return vehicleId;
    }
    public void setVehicleId(Long vehicleId) {
        this.vehicleId = vehicleId;
    }

    public String getSelectedProvider() {
        return selectedProvider;
    }
    public void setSelectedProvider(String selectedProvider) {
        this.selectedProvider = selectedProvider;
    }

    public String getSelectedPlan() {
        return selectedPlan;
    }
    public void setSelectedPlan(String selectedPlan) {
        this.selectedPlan = selectedPlan;
    }

    public Double getPremiumAmount() {
        return premiumAmount;
    }
    public void setPremiumAmount(Double premiumAmount) {
        this.premiumAmount = premiumAmount;
    }
}
