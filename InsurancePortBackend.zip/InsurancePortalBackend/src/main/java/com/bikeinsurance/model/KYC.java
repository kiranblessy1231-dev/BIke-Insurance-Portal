package com.bikeinsurance.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "kyc")
public class KYC {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "insurance_quote_id", nullable = false)
    private InsuranceQuote insuranceQuote;

    @Column(nullable = false)
    private String drivingLicensePath;

    @Column(nullable = false)
    private String rcPath;

    @Column(nullable = false)
    private String aadharPath;

    @Column(nullable = false)
    private String verificationStatus;

    @Column(nullable = false, updatable = false)
    private LocalDateTime uploadedAt = LocalDateTime.now();

    public KYC() {}

    public KYC(Long id, InsuranceQuote insuranceQuote, String drivingLicensePath,
               String rcPath, String aadharPath, String verificationStatus,
               LocalDateTime uploadedAt) {
        this.id = id;
        this.insuranceQuote = insuranceQuote;
        this.drivingLicensePath = drivingLicensePath;
        this.rcPath = rcPath;
        this.aadharPath = aadharPath;
        this.verificationStatus = verificationStatus;
        this.uploadedAt = uploadedAt;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public InsuranceQuote getInsuranceQuote() { return insuranceQuote; }
    public void setInsuranceQuote(InsuranceQuote insuranceQuote) { this.insuranceQuote = insuranceQuote; }

    public String getDrivingLicensePath() { return drivingLicensePath; }
    public void setDrivingLicensePath(String drivingLicensePath) { this.drivingLicensePath = drivingLicensePath; }

    public String getRcPath() { return rcPath; }
    public void setRcPath(String rcPath) { this.rcPath = rcPath; }

    public String getAadharPath() { return aadharPath; }
    public void setAadharPath(String aadharPath) { this.aadharPath = aadharPath; }

    public String getVerificationStatus() { return verificationStatus; }
    public void setVerificationStatus(String verificationStatus) { this.verificationStatus = verificationStatus; }

    public LocalDateTime getUploadedAt() { return uploadedAt; }
    public void setUploadedAt(LocalDateTime uploadedAt) { this.uploadedAt = uploadedAt; }
}
