package com.bikeinsurance.service;

import com.bikeinsurance.model.Vehicle;
import com.bikeinsurance.dto.InsuranceQuoteResponseDTO;
import org.springframework.stereotype.Service;

@Service
public class InsuranceCalculatorService {

    private static final int CURRENT_YEAR = 2025;


public InsuranceQuoteResponseDTO calculatePolicyBazaar(Vehicle vehicle) {
    double baseAmount = 2000;
    double accident = vehicle.getNoOfDrivingAccidents() * 300;
    double violation = vehicle.getNoOfDrivingViolations() * 200;
    double age = (CURRENT_YEAR - vehicle.getVehicleYear()) * 100;

    double basePremium = baseAmount + accident + violation + age;

    return new InsuranceQuoteResponseDTO(
        "PolicyBazaar",
        basePremium,             // BASIC
        basePremium * 1.5        // PREMIUM
    );
}

    public InsuranceQuoteResponseDTO calculateAcko(Vehicle vehicle) {
        double baseAmount = 1800;
        double accident = vehicle.getNoOfDrivingAccidents() * 250;
        double violation = vehicle.getNoOfDrivingViolations() * 180;
        double age = (CURRENT_YEAR - vehicle.getVehicleYear()) * 80;

        double basePremium = baseAmount + accident + violation + age;

        return new InsuranceQuoteResponseDTO(
            "Acko",
            basePremium,             // BASIC
            basePremium * 1.6
            );
    }

    public InsuranceQuoteResponseDTO calculateIcici(Vehicle vehicle) {
        double baseAmount = 2200;
        double accident = vehicle.getNoOfDrivingAccidents() * 350;
        double violation = vehicle.getNoOfDrivingViolations() * 220;
        double age = (CURRENT_YEAR - vehicle.getVehicleYear()) * 120;

        double basePremium = baseAmount + accident + violation + age;

        return new InsuranceQuoteResponseDTO(
            "ICICI",
            basePremium,             // BASIC
            basePremium * 1.7
            );
    }

    public InsuranceQuoteResponseDTO calculateDigit(Vehicle vehicle) {
        double baseAmount = 1900;
        double accident = vehicle.getNoOfDrivingAccidents() * 280;
        double violation = vehicle.getNoOfDrivingViolations() * 190;
        double age = (CURRENT_YEAR - vehicle.getVehicleYear()) * 90;

        double basePremium = baseAmount + accident + violation + age;

        return new InsuranceQuoteResponseDTO(
            "Digit",
            basePremium,             // BASIC
            basePremium * 1.75
            );
    }
}

