package com.bikeinsurance.service;

import com.bikeinsurance.model.KYC;
import com.bikeinsurance.model.InsuranceQuote;
import com.bikeinsurance.repository.KYCRepository;
import com.bikeinsurance.repository.InsuranceQuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@Service
public class KYCService {

    @Autowired
    private KYCRepository kycRepository;

    @Autowired
    private InsuranceQuoteRepository insuranceQuoteRepository;

    @Autowired
    private InsuranceQuoteService quoteService;

    // Fixed absolute path for Windows - change this to match your system
    private static final String UPLOAD_DIR = "C:/BikeInsurance/uploads/kyc/";
    private static final long MAX_FILE_SIZE = 5 * 1024 * 1024;

    public KYC uploadKYC(
            Long insuranceQuoteId,
            MultipartFile drivingLicense,
            MultipartFile rc,
            MultipartFile aadhar) throws IOException {

        System.out.println("[INFO] Starting KYC upload for Quote ID: " + insuranceQuoteId);

        validatePDFFile(drivingLicense);
        validatePDFFile(rc);
        validatePDFFile(aadhar);

        String dlPath = saveFile(drivingLicense, "DL");
        String rcPath = saveFile(rc, "RC");
        String aadharPath = saveFile(aadhar, "AADHAR");

        System.out.println("[INFO] Files saved. Fetching quote...");
        InsuranceQuote quote = quoteService.getQuoteById(insuranceQuoteId);
        if (quote == null) {
            System.err.println("[ERROR] Quote not found for ID: " + insuranceQuoteId);
            throw new IllegalArgumentException("Invalid Insurance Quote ID: " + insuranceQuoteId);
        }

        System.out.println("[SUCCESS] Quote found: " + quote.getId() + " - " + quote.getSelectedProvider());

        KYC kyc = new KYC();
        kyc.setInsuranceQuote(quote);
        kyc.setDrivingLicensePath(dlPath);
        kyc.setRcPath(rcPath);
        kyc.setAadharPath(aadharPath);
        kyc.setVerificationStatus("APPROVED");

        KYC saved = kycRepository.save(kyc);
        System.out.println("[SUCCESS] KYC saved with ID: " + saved.getId());

        // Update the existing quote status (don't create a new one)
        quote.setKyc(saved);
        quote.setStatus("APPROVED");
        insuranceQuoteRepository.save(quote);  // Update existing quote instead of creating new one

        System.out.println("[SUCCESS] Quote ID " + quote.getId() + " status updated to APPROVED");

        return saved;
    }

    // ------------------ HELPER METHODS ------------------

    private void validatePDFFile(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("File is required");
        }

        if (!"application/pdf".equals(file.getContentType())) {
            throw new IllegalArgumentException("Only PDF files are allowed");
        }

        if (file.getSize() > MAX_FILE_SIZE) {
            throw new IllegalArgumentException("File size exceeds 5MB");
        }
    }

    private String saveFile(MultipartFile file, String type) throws IOException {

        String fileName = UUID.randomUUID() + "_" + type + ".pdf";

        // Create directory structure
        File uploadDir = new File(UPLOAD_DIR);
        if (!uploadDir.exists()) {
            boolean created = uploadDir.mkdirs();
            if (!created && !uploadDir.exists()) {
                throw new IOException("Cannot create upload directory: " + UPLOAD_DIR);
            }
            System.out.println("[SUCCESS] Created directory: " + uploadDir.getAbsolutePath());
        }

        // Save file using simple path construction
        String fullPath = UPLOAD_DIR + fileName;
        File savedFile = new File(fullPath);
        
        System.out.println("[INFO] Saving file to: " + savedFile.getAbsolutePath());
        
        try {
            byte[] bytes = file.getBytes();
            java.nio.file.Files.write(savedFile.toPath(), bytes);
            System.out.println("[SUCCESS] File saved: " + savedFile.getName());
        } catch (IOException e) {
            System.err.println("[ERROR] Save failed: " + e.getMessage());
            throw new IOException("Cannot save file to: " + fullPath + ". " + e.getMessage());
        }

        return fullPath;
    }
}
