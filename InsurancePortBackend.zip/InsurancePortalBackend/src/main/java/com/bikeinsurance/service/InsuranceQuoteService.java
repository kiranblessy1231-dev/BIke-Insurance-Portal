package com.bikeinsurance.service;

import com.bikeinsurance.model.*;
import com.bikeinsurance.dto.InsuranceQuoteResponseDTO;
import com.bikeinsurance.repository.InsuranceQuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class InsuranceQuoteService {

    @Autowired
    private InsuranceQuoteRepository insuranceQuoteRepository;

    @Autowired
    private InsuranceCalculatorService calculatorService;

    @Autowired
    private VehicleService vehicleService;

    @Autowired
    private UserService userService;


    public List<InsuranceQuoteResponseDTO> getQuotes(Long vehicleId) {

        Vehicle vehicle = vehicleService.getVehicleById(vehicleId);

        if (vehicle == null) {
            throw new IllegalArgumentException("Vehicle not found with ID: " + vehicleId);
        }

        return List.of(
            calculatorService.calculatePolicyBazaar(vehicle),
            calculatorService.calculateAcko(vehicle),
            calculatorService.calculateIcici(vehicle),
            calculatorService.calculateDigit(vehicle)
        );
    }

    public InsuranceQuote saveQuote(String userId,  // changed Long -> String
            Long vehicleId,
            String provider,
            String plan,
            Double premium) {

InsuranceQuote quote = new InsuranceQuote();
// Fetch user by UUID string
quote.setUser(userService.getUserByUserId(userId));
quote.setVehicle(vehicleService.getVehicleById(vehicleId));
quote.setSelectedProvider(provider);
quote.setSelectedPlan(plan);
quote.setPremiumAmount(premium);
quote.setStatus("PENDING_KYC");

return insuranceQuoteRepository.save(quote);
}



    public InsuranceQuote getQuoteById(Long id) {
        return insuranceQuoteRepository.findById(id).orElse(null);
    }


    public List<InsuranceQuote> getAllApplications() {
        return insuranceQuoteRepository.findAll();
    }
}
