package com.bikeinsurance.controller;

import com.bikeinsurance.model.InsuranceQuote;
import com.bikeinsurance.dto.AdminApplicationViewDTO;
import com.bikeinsurance.service.InsuranceQuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins = "http://localhost:4200")
public class AdminController {
    @Autowired
    private InsuranceQuoteService quoteService;
    
    @GetMapping("/allApplications")
    public ResponseEntity<Map<String, Object>> getAllApplications() {
        try {
            System.out.println("[ADMIN] Fetching all applications...");
            List<InsuranceQuote> applications = quoteService.getAllApplications();
            System.out.println("[ADMIN] Found " + applications.size() + " total applications");
            
            // Group by userId and vehicleNumber to avoid duplicates, keep only APPROVED applications
            Map<String, InsuranceQuote> uniqueApplications = new HashMap<>();
            
            for (InsuranceQuote app : applications) {
                String key = app.getUser().getUserId() + "_" + app.getVehicle().getVehicleNumber();
                
                // Only add if KYC is uploaded AND approved
                if (app.getKyc() != null && "APPROVED".equals(app.getKyc().getVerificationStatus())) {
                    // If key doesn't exist or current app has higher ID (more recent), add/replace it
                    if (!uniqueApplications.containsKey(key) || 
                        app.getId() > uniqueApplications.get(key).getId()) {
                        uniqueApplications.put(key, app);
                        System.out.println("[ADMIN] Added/Updated unique key: " + key + " with ID: " + app.getId());
                    } else {
                        System.out.println("[ADMIN] Skipped duplicate for key: " + key + ", ID: " + app.getId());
                    }
                } else {
                    String status = app.getKyc() != null ? app.getKyc().getVerificationStatus() : "NO_KYC";
                    System.out.println("[ADMIN] Skipped application ID: " + app.getId() + " (Status: " + status + ")");
                }
            }
            
            List<AdminApplicationViewDTO> result = new ArrayList<>();
            
            for (InsuranceQuote app : uniqueApplications.values()) {
                String kycStatus = app.getKyc().getVerificationStatus();
                System.out.println("[ADMIN] Including in results - ID: " + app.getId() 
                    + ", User: " + app.getUser().getName()
                    + ", Vehicle: " + app.getVehicle().getVehicleNumber()
                    + ", Provider: " + app.getSelectedProvider()
                    + ", KYC Status: " + kycStatus);
                
                String appliedAt = app.getAppliedAt() != null ? app.getAppliedAt().toString() : new java.util.Date().toString();
                
                AdminApplicationViewDTO dto = new AdminApplicationViewDTO(
                    app.getId(),
                    app.getUser().getName(),
                    app.getUser().getEmail(),
                    app.getVehicle().getVehicleNumber(),
                    app.getSelectedProvider(),
                    app.getSelectedPlan(),
                    app.getPremiumAmount(),
                    kycStatus,
                    appliedAt
                );
                result.add(dto);
            }
            
            // Sort by ID descending (latest first)
            result.sort((a, b) -> Long.compare(b.getId(), a.getId()));
            
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("applications", result);
            
            System.out.println("[ADMIN] Returning " + result.size() + " unique completed applications to frontend");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            System.err.println("[ADMIN ERROR] " + e.getMessage());
            e.printStackTrace();
            return ResponseEntity.badRequest().body(
                Map.of("success", false, "message", e.getMessage())
            );
        }
    }
}
