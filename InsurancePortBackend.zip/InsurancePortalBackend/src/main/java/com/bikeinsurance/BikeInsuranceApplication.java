package com.bikeinsurance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikeInsuranceApplication {
    public static void main(String[] args) {
        SpringApplication.run(BikeInsuranceApplication.class, args);
    }
}
