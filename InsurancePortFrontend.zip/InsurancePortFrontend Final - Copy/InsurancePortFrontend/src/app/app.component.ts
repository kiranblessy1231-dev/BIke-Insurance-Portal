import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from './services/auth.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, CommonModule],
  template: `
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" routerLink="/">
          <i class="bi bi-shield-check"></i> Bike Insurance Portal
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto">
            <li class="nav-item">
              <a class="nav-link" routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact: true}">
                Home
              </a>
            </li>
            <li class="nav-item" *ngIf="!isAdminLoggedIn()">
              <a class="nav-link" routerLink="/vehicle-check" routerLinkActive="active">
                Check Vehicle
              </a>
            </li>
            <li class="nav-item" *ngIf="isAdminLoggedIn()">
              <a class="nav-link" routerLink="/admin-applications" routerLinkActive="active">
                Applications
              </a>
            </li>
            <li class="nav-item" *ngIf="isAdminLoggedIn()">
              <button class="btn btn-outline-light btn-sm ms-2" (click)="logout()">
                Logout
              </button>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <main>
      <router-outlet></router-outlet>
    </main>

    <footer class="bg-dark text-white text-center py-3 mt-5">
      <p class="mb-0">&copy; 2025 Bike Insurance Portal. All rights reserved.</p>
    </footer>
  `,
  styles: [`
    main {
      min-height: calc(100vh - 120px);
    }
    footer {
      margin-top: auto;
    }
  `]
})
export class AppComponent {
  title = 'bike-insurance';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  isAdminLoggedIn(): boolean {
    return this.authService.isAdminLoggedIn();
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/']);
  }
}
