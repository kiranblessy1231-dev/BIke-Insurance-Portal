import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehicleService } from '../../services/vehicle.service';
import { Vehicle } from '../../models/vehicle.model';

@Component({
  selector: 'app-vehicle-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <div class="card">
        <div class="card-header bg-primary text-white">
          <h3 class="mb-0">{{ isUpdate ? 'Update Vehicle Details' : 'Vehicle Registration' }}</h3>
        </div>
        <div class="card-body">
          <form (ngSubmit)="submitVehicle()" #vehicleForm="ngForm">
            <div class="mb-3">
              <label class="form-label">Vehicle Number *</label>
              <input 
                type="text" 
                [(ngModel)]="vehicle.vehicleNumber" 
                name="vehicleNumber"
                class="form-control" 
                placeholder="e.g., KA01AB1234"
                [readonly]="isUpdate"
                required
                pattern="[A-Z]{2}[0-9]{2}[A-Z]{1,2}[0-9]{4}"
                (input)="vehicle.vehicleNumber = vehicle.vehicleNumber.toUpperCase()"
                #vehicleNumber="ngModel">
              <div *ngIf="vehicleNumber.invalid && vehicleNumber.touched" class="text-danger">
                Valid vehicle number required (e.g., KA01AB1234)
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Vehicle Year *</label>
              <input 
                type="number" 
                [(ngModel)]="vehicle.vehicleYear" 
                name="vehicleYear"
                class="form-control" 
                placeholder="e.g., 2020"
                required
                [min]="1900"
                [max]="currentYear"
                #vehicleYear="ngModel">
              <div *ngIf="vehicleYear.invalid && vehicleYear.touched" class="text-danger">
                Valid year between 1900 and {{ currentYear }} required
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Number of Driving Accidents *</label>
              <input 
                type="number" 
                [(ngModel)]="vehicle.noOfDrivingAccidents" 
                name="accidents"
                class="form-control" 
                required
                min="0"
                #accidents="ngModel">
              <div *ngIf="accidents.invalid && accidents.touched" class="text-danger">
                Value cannot be negative
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Number of Driving Violations *</label>
              <input 
                type="number" 
                [(ngModel)]="vehicle.noOfDrivingViolations" 
                name="violations"
                class="form-control" 
                required
                min="0"
                #violations="ngModel">
              <div *ngIf="violations.invalid && violations.touched" class="text-danger">
                Value cannot be negative
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Coverage Type *</label>
              <select 
                [(ngModel)]="vehicle.coverageType" 
                name="coverageType"
                class="form-select" 
                required
                #coverageType="ngModel">
                <option value="">-- Select Coverage Type --</option>
                <option value="Comprehensive">Comprehensive</option>
                <option value="Third Party">Third Party</option>
              </select>
              <div *ngIf="coverageType.invalid && coverageType.touched" class="text-danger">
                Coverage type is required
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Coverage Amount (₹) *</label>
              <input 
                type="number" 
                [(ngModel)]="vehicle.coverageAmount" 
                name="coverageAmount"
                class="form-control" 
                placeholder="e.g., 100000"
                required
                min="1"
                #coverageAmount="ngModel">
              <div *ngIf="coverageAmount.invalid && coverageAmount.touched" class="text-danger">
                Coverage amount must be greater than 0
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Coverage Deductibles (₹) *</label>
              <input 
                type="number" 
                [(ngModel)]="vehicle.coverageDeductibles" 
                name="deductibles"
                class="form-control" 
                placeholder="e.g., 5000"
                required
                min="1"
                #deductibles="ngModel">
              <div *ngIf="deductibles.invalid && deductibles.touched" class="text-danger">
                Deductibles must be greater than 0
              </div>
            </div>

            <div *ngIf="errorMessage" class="alert alert-danger">
              {{ errorMessage }}
            </div>

            <button 
              type="submit" 
              class="btn btn-primary w-100"
              [disabled]="vehicleForm.invalid || submitting">
              {{ submitting ? 'Saving...' : (isUpdate ? 'Update & Get Quotes' : 'Register & Get Quotes') }}
            </button>
          </form>
        </div>
      </div>
    </div>
  `
})
export class VehicleFormComponent implements OnInit {
  vehicle: Vehicle = {
    userId: '',
    vehicleNumber: '',
    vehicleYear: new Date().getFullYear(),
    noOfDrivingAccidents: 0,
    noOfDrivingViolations: 0,
    coverageType: '',
    coverageAmount: 0,
    coverageDeductibles: 0
  };
  currentYear = new Date().getFullYear();
  isUpdate: boolean = false;
  errorMessage: string = '';
  submitting: boolean = false;

  constructor(
    private vehicleService: VehicleService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['userId']) {
        this.vehicle.userId = params['userId'];
      }
      if (params['vehicleNumber']) {
        this.vehicle.vehicleNumber = params['vehicleNumber'];
      }
      if (params['update'] === 'true') {
        this.isUpdate = true;
        this.loadVehicleData();
      }
    });
  }

  loadVehicleData(): void {
    if (this.vehicle.vehicleNumber) {
      this.vehicleService.getVehicleByNumber(this.vehicle.vehicleNumber).subscribe({
        next: (data) => {
          this.vehicle = data;
        },
        error: (err) => {
          console.error('Error loading vehicle:', err);
        }
      });
    }
  }

  submitVehicle(): void {
    this.errorMessage = '';
    this.submitting = true;

    const operation = this.isUpdate 
      ? this.vehicleService.updateVehicle(this.vehicle.vehicleNumber, this.vehicle)
      : this.vehicleService.saveVehicle(this.vehicle);

    operation.subscribe({
      next: (savedVehicle) => {
        this.submitting = false;
        this.router.navigate(['/quotes'], {
          queryParams: { 
            vehicleNumber: savedVehicle.vehicleNumber,
            userId: savedVehicle.userId
          }
        });
      },
      error: (err) => {
        console.error('Error saving vehicle:', err);
        this.errorMessage = err.message || 'Failed to save vehicle. Please try again.';
        this.submitting = false;
      }
    });
  }
}