import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-user-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <div class="card">
        <div class="card-header bg-success text-white">
          <h3 class="mb-0">User Registration</h3>
        </div>
        <div class="card-body">
          <form (ngSubmit)="submitUser()" #userForm="ngForm">
            <div class="mb-3">
              <label class="form-label">Full Name *</label>
              <input 
                type="text" 
                [(ngModel)]="user.name" 
                name="name"
                class="form-control" 
                placeholder="Enter your full name"
                required
                minlength="2"
                #name="ngModel">
              <div *ngIf="name.invalid && name.touched" class="text-danger">
                Name is required (minimum 2 characters)
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Email *</label>
              <input 
                type="email" 
                [(ngModel)]="user.email" 
                name="email"
                class="form-control" 
                placeholder="Enter your email"
                required
                pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}"
                #email="ngModel">
              <div *ngIf="email.invalid && email.touched" class="text-danger">
                Valid email is required
              </div>
            </div>

            <div class="mb-3">
              <label class="form-label">Phone Number *</label>
              <input 
                type="tel" 
                [(ngModel)]="user.phone" 
                name="phone"
                class="form-control" 
                placeholder="Enter 10-digit mobile number"
                required
                pattern="[6-9][0-9]{9}"
                maxlength="10"
                #phone="ngModel">
              <div *ngIf="phone.invalid && phone.touched" class="text-danger">
                Valid 10-digit phone number is required (starting with 6-9)
              </div>
            </div>

            <div *ngIf="errorMessage" class="alert alert-danger">
              {{ errorMessage }}
            </div>

            <div class="btn-group w-100">
              <button 
                type="submit" 
                class="btn btn-success"
                [disabled]="userForm.invalid || submitting">
                {{ submitting ? 'Saving...' : 'Next: Vehicle Registration' }}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  `
})
export class UserFormComponent implements OnInit {
  user: User = {
-    userId: '',
+    userId: 0, // numeric initial value
    name: '',
    email: '',
    phone: ''
  };
  vehicleNumber: string = '';
  errorMessage: string = '';
  submitting: boolean = false;

  constructor(
    private userService: UserService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      if (params['vehicleNumber']) {
        this.vehicleNumber = params['vehicleNumber'];
      }
    });
  }

  submitUser(): void {
    this.errorMessage = '';
    this.submitting = true;

    this.userService.saveUser(this.user).subscribe({
      next: (savedUser) => {
        this.submitting = false;
        this.router.navigate(['/vehicle-form'], {
          queryParams: { 
            userId: savedUser.userId,
            vehicleNumber: this.vehicleNumber
          }
        });
      },
      error: (err) => {
        console.error('Error saving user:', err);
        this.errorMessage = err.message || 'Failed to save user. Please try again.';
        this.submitting = false;
      }
    });
  }
}
