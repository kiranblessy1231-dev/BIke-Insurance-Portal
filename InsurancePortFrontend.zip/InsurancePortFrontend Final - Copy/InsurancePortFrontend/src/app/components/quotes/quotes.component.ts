// src/app/components/quotes/quotes.component.ts
// REPLACE ENTIRE FILE
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { InsuranceService } from '../../services/insurance.service';
import { VehicleService } from '../../services/vehicle.service';
import { InsuranceQuote, InsuranceApplication } from '../../models/insurance-quote.model';

@Component({
  selector: 'app-quotes',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="quotes-container">
      <div class="quotes-header">
        <h1><i class="bi bi-calculator-fill"></i> Insurance Quotes</h1>
        <p>Compare plans and choose the best insurance for your bike</p>
      </div>

      <!-- Loading State -->
      <div *ngIf="loading" class="loading-section">
        <div class="spinner-border"></div>
        <p>Calculating insurance quotes...</p>
      </div>

      <!-- Error Message -->
      <div *ngIf="errorMessage" class="alert alert-danger">
        <i class="bi bi-exclamation-triangle-fill"></i> 
        <span>{{ errorMessage }}</span>
      </div>

      <!-- No Quotes -->
      <div *ngIf="!loading && quotes.length === 0 && !errorMessage" class="alert alert-info">
        <i class="bi bi-info-circle-fill"></i> 
        <span>No quotes available for this vehicle.</span>
      </div>

      <!-- Quotes Grid -->
      <div *ngIf="!loading && quotes.length > 0" class="quotes-grid">
        <div *ngFor="let quote of quotes" class="quote-card">
          <div class="provider-header">
            <div class="provider-logo">
              <i class="bi bi-shield-fill-check"></i>
            </div>
            <h3>{{ quote.providerName }}</h3>
            <p class="tagline">Trusted Insurance Provider</p>
          </div>

          <div class="plans-container">
            <!-- Basic Plan -->
            <div class="plan basic-plan">
              <div class="plan-badge">Basic</div>
              <div class="price-section">
                <div class="price">
                  <span class="currency">₹</span>
                  <span class="amount">{{ quote.basic | number:'1.0-0' }}</span>
                </div>
                <p class="period">per year</p>
              </div>
              
              <ul class="features">
                <li><i class="bi bi-check-circle-fill"></i> Third Party Coverage</li>
                <li><i class="bi bi-check-circle-fill"></i> Personal Accident Cover</li>
                <li><i class="bi bi-check-circle-fill"></i> Basic Protection</li>
                <li><i class="bi bi-check-circle-fill"></i> 24/7 Support</li>
              </ul>
              
              <button class="select-btn basic-btn" (click)="selectPlan(quote, 'Basic')">
                <i class="bi bi-arrow-right-circle-fill"></i>
                Select Basic
              </button>
            </div>

            <!-- Premium Plan -->
            <div class="plan premium-plan">
              <div class="plan-badge premium-badge">
                <i class="bi bi-star-fill"></i> Premium
              </div>
              <div class="price-section">
                <div class="price">
                  <span class="currency">₹</span>
                  <span class="amount">{{ quote.premium | number:'1.0-0' }}</span>
                </div>
                <p class="period">per year</p>
              </div>
              
              <ul class="features">
                <li><i class="bi bi-check-circle-fill"></i> Comprehensive Coverage</li>
                <li><i class="bi bi-check-circle-fill"></i> Zero Depreciation</li>
                <li><i class="bi bi-check-circle-fill"></i> Roadside Assistance</li>
                <li><i class="bi bi-check-circle-fill"></i> Engine Protection</li>
                <li><i class="bi bi-check-circle-fill"></i> Return to Invoice</li>
                <li><i class="bi bi-check-circle-fill"></i> Key Replacement</li>
              </ul>
              
              <button class="select-btn premium-btn" (click)="selectPlan(quote, 'Premium')">
                <i class="bi bi-arrow-right-circle-fill"></i>
                Select Premium
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Selection Confirmation -->
      <div *ngIf="processingSelection" class="selection-overlay">
        <div class="selection-card">
          <div class="spinner-border"></div>
          <p>Processing your selection...</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .quotes-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 40px 20px;
    }

    .quotes-header {
      text-align: center;
      color: white;
      margin-bottom: 50px;
      animation: fadeInDown 0.6s ease;
    }

    .quotes-header h1 {
      font-size: 3rem;
      font-weight: 800;
      margin-bottom: 15px;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 20px;
    }

    .quotes-header p {
      font-size: 1.3rem;
      opacity: 0.95;
    }

    .loading-section {
      text-align: center;
      color: white;
      padding: 80px 20px;
      animation: fadeIn 0.5s ease;
    }

    .loading-section .spinner-border {
      width: 4rem;
      height: 4rem;
      border: 5px solid rgba(255,255,255,0.3);
      border-top-color: white;
      margin-bottom: 25px;
    }

    .loading-section p {
      font-size: 1.3rem;
      font-weight: 500;
    }

    .alert {
      max-width: 700px;
      margin: 20px auto;
      padding: 25px 30px;
      border-radius: 20px;
      display: flex;
      align-items: center;
      gap: 20px;
      font-size: 1.2rem;
      font-weight: 600;
      animation: slideUp 0.5s ease;
    }

    .alert-danger {
      background: white;
      color: #d32f2f;
      border: 3px solid #ff6b6b;
      box-shadow: 0 10px 30px rgba(255,107,107,0.3);
    }

    .alert-info {
      background: white;
      color: #1976d2;
      border: 3px solid #667eea;
      box-shadow: 0 10px 30px rgba(102,126,234,0.3);
    }

    .alert i {
      font-size: 2rem;
    }

    .quotes-grid {
      max-width: 1400px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(600px, 1fr));
      gap: 35px;
      animation: fadeIn 0.8s ease;
    }

    .quote-card {
      background: white;
      border-radius: 25px;
      overflow: hidden;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      transition: transform 0.3s ease;
    }

    .quote-card:hover {
      transform: translateY(-10px);
    }

    .provider-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 35px;
      text-align: center;
    }

    .provider-logo {
      width: 90px;
      height: 90px;
      background: rgba(255,255,255,0.2);
      backdrop-filter: blur(10px);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto 20px;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }

    .provider-logo i {
      font-size: 3rem;
    }

    .provider-header h3 {
      font-size: 2rem;
      font-weight: 700;
      margin: 0 0 8px;
    }

    .tagline {
      font-size: 1rem;
      opacity: 0.9;
      margin: 0;
    }

    .plans-container {
      padding: 35px;
      display: flex;
      gap: 25px;
    }

    .plan {
      flex: 1;
      padding: 30px;
      border-radius: 20px;
      position: relative;
      transition: all 0.3s ease;
      display: flex;
      flex-direction: column;
    }

    .basic-plan {
      background: #f8f9fa;
      border: 3px solid #e0e0e0;
    }

    .premium-plan {
      background: linear-gradient(135deg, #fff5f5 0%, #ffe5e5 100%);
      border: 3px solid #667eea;
      box-shadow: 0 5px 25px rgba(102,126,234,0.2);
    }

    .plan:hover {
      transform: scale(1.03);
    }

    .plan-badge {
      position: absolute;
      top: 20px;
      right: 20px;
      padding: 8px 18px;
      background: #666;
      color: white;
      border-radius: 50px;
      font-size: 0.9rem;
      font-weight: 700;
      letter-spacing: 0.5px;
    }

    .premium-badge {
      background: linear-gradient(135deg, #ffd93d 0%, #ff9ff3 100%);
      color: #333;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .price-section {
      text-align: center;
      margin: 25px 0 30px;
    }

    .price {
      display: flex;
      align-items: flex-start;
      justify-content: center;
      margin-bottom: 8px;
    }

    .currency {
      font-size: 1.8rem;
      font-weight: 700;
      color: #666;
      margin-top: 8px;
      margin-right: 5px;
    }

    .amount {
      font-size: 3.5rem;
      font-weight: 900;
      color: #333;
      line-height: 1;
    }

    .period {
      font-size: 1rem;
      color: #999;
      margin: 0;
    }

    .features {
      list-style: none;
      padding: 0;
      margin: 0 0 30px;
      flex-grow: 1;
    }

    .features li {
      padding: 12px 0;
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 1rem;
      color: #555;
      border-bottom: 1px solid #eee;
    }

    .features li:last-child {
      border-bottom: none;
    }

    .features i {
      color: #4caf50;
      font-size: 1.3rem;
      flex-shrink: 0;
    }

    .premium-plan .features i {
      color: #667eea;
    }

    .select-btn {
      width: 100%;
      padding: 18px;
      border: none;
      border-radius: 50px;
      font-size: 1.1rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      margin-top: auto;
    }

    .basic-btn {
      background: #333;
      color: white;
      box-shadow: 0 5px 20px rgba(0,0,0,0.2);
    }

    .basic-btn:hover {
      background: #555;
      transform: translateY(-3px);
      box-shadow: 0 8px 25px rgba(0,0,0,0.3);
    }

    .premium-btn {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      box-shadow: 0 5px 20px rgba(102,126,234,0.4);
    }

    .premium-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 30px rgba(102,126,234,0.5);
    }

    .selection-overlay {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.7);
      backdrop-filter: blur(5px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 1000;
      animation: fadeIn 0.3s ease;
    }

    .selection-card {
      background: white;
      padding: 50px;
      border-radius: 20px;
      text-align: center;
      box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    }

    .selection-card .spinner-border {
      width: 3rem;
      height: 3rem;
      border: 4px solid #e0e0e0;
      border-top-color: #667eea;
      margin-bottom: 20px;
    }

    .selection-card p {
      font-size: 1.2rem;
      font-weight: 600;
      color: #333;
    }

    @keyframes fadeInDown {
      from {
        opacity: 0;
        transform: translateY(-30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @media (max-width: 1200px) {
      .quotes-grid {
        grid-template-columns: 1fr;
      }
    }

    @media (max-width: 768px) {
      .quotes-header h1 {
        font-size: 2rem;
      }

      .plans-container {
        flex-direction: column;
      }

      .provider-header {
        padding: 25px;
      }
    }
  `]
})
export class QuotesComponent implements OnInit {
  quotes: InsuranceQuote[] = [];
  vehicleNumber: string = '';
  userId: string = '';
  vehicleId: number = 0;
  errorMessage: string = '';
  loading: boolean = false;
  processingSelection: boolean = false;

  constructor(
    private insuranceService: InsuranceService,
    private vehicleService: VehicleService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.vehicleNumber = params['vehicleNumber'];
      this.userId = params['userId'];
      const vehicleIdParam = params['vehicleId'];
      
      // If vehicleId is directly provided, use it immediately
      if (vehicleIdParam) {
        this.vehicleId = Number(vehicleIdParam);
        console.log('✅ Vehicle ID from params:', this.vehicleId);
        this.loadQuotesDirectly();
      } else if (this.vehicleNumber) {
        // Fallback: fetch vehicle by number to get ID
        this.loadQuotes();
      } else {
        this.errorMessage = 'Vehicle information is missing.';
      }
    });
  }

  loadQuotesDirectly(): void {
    this.loading = true;
    this.errorMessage = '';

    this.insuranceService.getQuotes(this.vehicleId).subscribe({
      next: (data) => {
        console.log('✅ Quotes loaded:', data);
        this.quotes = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('❌ Error loading quotes:', err);
        this.errorMessage = 'Failed to load insurance quotes. Please try again.';
        this.loading = false;
      }
    });
  }

  loadQuotes(): void {
    this.loading = true;
    this.errorMessage = '';

    this.vehicleService.getVehicleByNumber(this.vehicleNumber).subscribe({
      next: (vehicle) => {
        if (vehicle.id) {
          this.vehicleId = vehicle.id;
          this.insuranceService.getQuotes(vehicle.id).subscribe({
            next: (data) => {
              console.log('✅ Quotes loaded:', data);
              this.quotes = data;
              this.loading = false;
            },
            error: (err) => {
              console.error('❌ Quotes error:', err);
              this.errorMessage = 'Failed to fetch insurance quotes. Please try again.';
              this.loading = false;
            }
          });
        } else {
          this.errorMessage = 'Vehicle ID not found.';
          this.loading = false;
        }
      },
      error: (err) => {
        console.error('❌ Vehicle error:', err);
        this.errorMessage = 'Failed to fetch vehicle details.';
        this.loading = false;
      }
    });
  }

  selectPlan(quote: InsuranceQuote, plan: string): void {
    this.processingSelection = true;
    const premiumAmount = plan === 'Basic' ? quote.basic : quote.premium;

    const application: InsuranceApplication = {
      userId: this.userId,
      vehicleId: this.vehicleId,
      selectedProvider: quote.providerName,
      selectedPlan: plan,
      premiumAmount: premiumAmount
    };

    this.insuranceService.selectProvider(application).subscribe({
      next: (quoteId) => {
        console.log('✅ Provider selected, Quote ID:', quoteId);
        this.processingSelection = false;
        
        // Navigate to insurance details page
        this.router.navigate(['/insurance-details'], {
          queryParams: {
            quoteId: quoteId,
            vehicleNumber: this.vehicleNumber,
            provider: quote.providerName,
            plan: plan,
            premium: premiumAmount
          }
        });
      },
      error: (err) => {
        console.error('❌ Selection error:', err);
        this.processingSelection = false;
        this.errorMessage = 'Failed to select insurance provider. Please try again.';
      }
    });
  }
}