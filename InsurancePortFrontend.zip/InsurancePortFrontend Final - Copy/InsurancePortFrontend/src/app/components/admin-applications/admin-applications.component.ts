import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AdminService } from '../../services/admin.service';
import { AuthService } from '../../services/auth.service';
import { AdminApplication } from '../../models/admin-application.model';

@Component({
  selector: 'app-admin-applications',
  standalone: true,
  imports: [CommonModule],
  styleUrls: ['./admin-application.component.css'],
  template: `
    <div class="container mt-4">
      <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>All Insurance Applications</h2>
        <button class="btn btn-danger" (click)="logout()">Logout</button>
      </div>

      <div *ngIf="errorMessage" class="alert alert-danger">
        {{ errorMessage }}
      </div>

      <div *ngIf="loading" class="text-center">
        <div class="spinner-border" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>
      </div>

      <div *ngIf="!loading && applications.length === 0" class="alert alert-info">
        No applications found.
      </div>

      <div *ngIf="!loading && applications.length > 0" class="table-responsive">
        <table class="table table-bordered table-hover">
          <thead class="table-dark">
            <tr>
              <th>ID</th>
              <th>User Name</th>
              <th>Email</th>
              <th>Vehicle Number</th>
              <th>Provider</th>
              <th>Plan</th>
              <th>Premium (₹)</th>
              <th>KYC Status</th>
              <th>Applied At</th>
            </tr>
          </thead>
          <tbody>
            <tr *ngFor="let app of applications">
              <td>{{ app.id }}</td>
              <td>{{ app.userName }}</td>
              <td>{{ app.userEmail }}</td>
              <td>{{ app.vehicleNumber }}</td>
              <td>{{ app.selectedProvider }}</td>
              <td>{{ app.selectedPlan }}</td>
              <td>{{ app.premiumAmount | number:'1.2-2' }}</td>
              <td>
                <span 
                  class="badge"
                  [ngClass]="{
                    'bg-warning text-dark': app.kycStatus === 'PENDING' || app.kycStatus === 'PENDING_KYC',
                    'bg-success': app.kycStatus === 'APPROVED' || app.kycStatus === 'VERIFIED',
                    'bg-danger': app.kycStatus === 'REJECTED',
                    'bg-secondary': app.kycStatus === 'NOT_UPLOADED' || !app.kycStatus
                  }">
                  {{ app.kycStatus || 'NOT_UPLOADED' }}
                </span>
              </td>
              <td>{{ app.appliedAt | date:'short' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
   
})
export class AdminApplicationsComponent implements OnInit {
  applications: AdminApplication[] = [];
  errorMessage: string = '';
  loading: boolean = false;

  constructor(
    private adminService: AdminService,
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    console.log('Admin component initialized');
    this.loadApplications();
  }

  loadApplications(): void {
    this.loading = true;
    this.errorMessage = '';
    
    console.log('Loading applications...');
    this.adminService.getAllApplications().subscribe({
      next: (data) => {
        console.log('✅ Applications loaded:', data);
        this.applications = data || [];
        this.loading = false;
      },
      error: (err) => {
        console.error('❌ Error loading applications:', err);
        this.errorMessage = 'Failed to load applications. Please check if backend is running.';
        this.loading = false;
      }
    });
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/']);
  }
}