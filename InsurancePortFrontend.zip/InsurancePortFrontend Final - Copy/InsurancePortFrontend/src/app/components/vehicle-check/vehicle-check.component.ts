import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { VehicleService } from '../../services/vehicle.service';
import { Vehicle } from '../../models/vehicle.model';

@Component({
  selector: 'app-vehicle-check',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <div class="card">
        <div class="card-header bg-info text-white">
          <h3 class="mb-0">Check Vehicle Registration</h3>
        </div>
        <div class="card-body">
          <div class="mb-3">
            <label class="form-label">Vehicle Number</label>
            <input 
              type="text" 
              [(ngModel)]="vehicleNumber" 
              class="form-control" 
              placeholder="e.g., KA01AB1234"
              (input)="vehicleNumber = vehicleNumber.toUpperCase()">
            <small class="form-text text-muted">
              Format: State Code (2 letters) + District Code (2 digits) + Series (1-2 letters) + Number (4 digits)
            </small>
          </div>
          
          <button 
            class="btn btn-info text-white" 
            [disabled]="!vehicleNumber"
            (click)="checkVehicle()">
            Check Vehicle
          </button>

          <div *ngIf="errorMessage && !vehicle" class="alert alert-warning mt-3">
            {{ errorMessage }}
            <button class="btn btn-sm btn-primary mt-2" (click)="goToUserForm()">
              Register New User & Vehicle
            </button>
          </div>

          <div *ngIf="vehicle" class="mt-4">
            <h4>Vehicle Details Found</h4>
            <table class="table table-bordered">
              <tr>
                <th>Vehicle Number</th>
                <td>{{ vehicle.vehicleNumber }}</td>
              </tr>
              <tr>
                <th>User ID</th>
                <td>{{ vehicle.userId }}</td>
              </tr>
              <tr>
                <th>Vehicle Year</th>
                <td>{{ vehicle.vehicleYear }}</td>
              </tr>
              <tr>
                <th>Coverage Type</th>
                <td>{{ vehicle.coverageType }}</td>
              </tr>
              <tr>
                <th>Coverage Amount</th>
                <td>₹{{ vehicle.coverageAmount | number:'1.2-2' }}</td>
              </tr>
              <tr>
                <th>Coverage Deductibles</th>
                <td>₹{{ vehicle.coverageDeductibles | number:'1.2-2' }}</td>
              </tr>
              <tr>
                <th>Driving Accidents</th>
                <td>{{ vehicle.noOfDrivingAccidents }}</td>
              </tr>
              <tr>
                <th>Driving Violations</th>
                <td>{{ vehicle.noOfDrivingViolations }}</td>
              </tr>
            </table>

            <div class="btn-group" role="group">
              <button 
                class="btn btn-success" 
                (click)="updateDetails()">
                Update Vehicle Details
              </button>
              <button 
                class="btn btn-primary" 
                (click)="proceedToQuotes()">
                Get Insurance Quotes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class VehicleCheckComponent {
  vehicleNumber: string = '';
  vehicle: Vehicle | null = null;
  errorMessage: string = '';

  constructor(
    private vehicleService: VehicleService,
    private router: Router
  ) {}

  checkVehicle(): void {
    this.errorMessage = '';
    this.vehicle = null;

    this.vehicleService.getVehicleByNumber(this.vehicleNumber).subscribe({
      next: (data) => {
        this.vehicle = data;
      },
      error: (err) => {
        console.error('Vehicle not found:', err);
        this.errorMessage = 'Vehicle not found in our system. Please register.';
      }
    });
  }

  updateDetails(): void {
    if (this.vehicle) {
      this.router.navigate(['/vehicle-form'], {
        queryParams: { 
          vehicleNumber: this.vehicle.vehicleNumber,
          userId: this.vehicle.userId,
          update: 'true'
        }
      });
    }
  }

  proceedToQuotes(): void {
    if (this.vehicle) {
      this.router.navigate(['/quotes'], {
        queryParams: { 
          vehicleNumber: this.vehicle.vehicleNumber,
          userId: this.vehicle.userId
        }
      });
    }
  }

  goToUserForm(): void {
    this.router.navigate(['/user-form'], {
      queryParams: { vehicleNumber: this.vehicleNumber }
    });
  }
}