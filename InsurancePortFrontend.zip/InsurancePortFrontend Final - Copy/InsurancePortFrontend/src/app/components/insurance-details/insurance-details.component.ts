// src/app/components/insurance-details/insurance-details.component.ts
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-insurance-details',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="details-container">
      <div class="details-card">
        <div class="card-header">
          <i class="bi bi-file-text"></i>
          <div>
            <h2>Insurance Policy Details</h2>
            <p>{{ provider }} - {{ plan }} Plan</p>
          </div>
        </div>

        <div class="card-body">
          <div class="coverage-section">
            <h3><i class="bi bi-shield-check"></i> Coverage Details</h3>
            
            <div class="coverage-item">
              <div class="coverage-icon accident">
                <i class="bi bi-car-front"></i>
              </div>
              <div class="coverage-info">
                <h4>Accident Coverage</h4>
                <p>Comprehensive protection against all types of accidents including natural disasters</p>
                <span class="coverage-amount">Up to ₹{{ premium * 10 | number:'1.0-0' }}</span>
              </div>
            </div>

            <div class="coverage-item">
              <div class="coverage-icon theft">
                <i class="bi bi-lock"></i>
              </div>
              <div class="coverage-info">
                <h4>Theft Coverage</h4>
                <p>Full protection against theft and burglary with 24/7 claim support</p>
                <span class="coverage-amount">Up to ₹{{ premium * 8 | number:'1.0-0' }}</span>
              </div>
            </div>

            <div class="coverage-item">
              <div class="coverage-icon damage">
                <i class="bi bi-tools"></i>
              </div>
              <div class="coverage-info">
                <h4>Damage Coverage</h4>
                <p>Coverage for all repair and replacement costs due to accidental damage</p>
                <span class="coverage-amount">Up to ₹{{ premium * 6 | number:'1.0-0' }}</span>
              </div>
            </div>

            <div class="coverage-item" *ngIf="plan === 'Premium'">
              <div class="coverage-icon hospital">
                <i class="bi bi-hospital"></i>
              </div>
              <div class="coverage-info">
                <h4>Hospitalization</h4>
                <p>Medical expenses coverage for injuries sustained in accidents</p>
                <span class="coverage-amount">Up to ₹{{ premium * 4 | number:'1.0-0' }}</span>
              </div>
            </div>

            <div class="coverage-item">
              <div class="coverage-icon third-party">
                <i class="bi bi-people"></i>
              </div>
              <div class="coverage-info">
                <h4>Third Party Coverage</h4>
                <p>Protection against legal liability for injury or property damage to others</p>
                <span class="coverage-amount">Unlimited</span>
              </div>
            </div>
          </div>

          <div class="premium-summary">
            <div class="summary-row">
              <span>Provider:</span>
              <strong>{{ provider }}</strong>
            </div>
            <div class="summary-row">
              <span>Plan Type:</span>
              <strong class="plan-badge">{{ plan }}</strong>
            </div>
            <div class="summary-row">
              <span>Vehicle:</span>
              <strong>{{ vehicleNumber }}</strong>
            </div>
            <div class="summary-row total">
              <span>Total Premium:</span>
              <strong class="price">₹{{ premium | number:'1.2-2' }}/year</strong>
            </div>
          </div>

          <div class="benefits-section" *ngIf="plan === 'Premium'">
            <h3><i class="bi bi-star-fill"></i> Additional Premium Benefits</h3>
            <ul class="benefits-list">
              <li><i class="bi bi-check-circle-fill"></i> Zero Depreciation Cover</li>
              <li><i class="bi bi-check-circle-fill"></i> Engine Protection Cover</li>
              <li><i class="bi bi-check-circle-fill"></i> 24/7 Roadside Assistance</li>
              <li><i class="bi bi-check-circle-fill"></i> Return to Invoice Cover</li>
              <li><i class="bi bi-check-circle-fill"></i> Consumables Cover</li>
              <li><i class="bi bi-check-circle-fill"></i> Key Replacement Cover</li>
            </ul>
          </div>
        </div>

        <div class="card-footer">
          <button class="action-btn proceed-btn" (click)="proceedToKYC()">
            <i class="bi bi-arrow-right-circle"></i>
            Get Insurance for this Vehicle
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .details-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      padding: 40px 20px;
    }

    .details-card {
      max-width: 1000px;
      margin: 0 auto;
      background: white;
      border-radius: 20px;
      box-shadow: 0 20px 60px rgba(0,0,0,0.3);
      overflow: hidden;
      animation: slideUp 0.6s ease;
    }

    .card-header {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      padding: 40px;
      display: flex;
      align-items: center;
      gap: 20px;
    }

    .card-header i {
      font-size: 3.5rem;
    }

    .card-header h2 {
      font-size: 2rem;
      font-weight: 700;
      margin: 0 0 5px;
    }

    .card-header p {
      font-size: 1.2rem;
      opacity: 0.9;
      margin: 0;
    }

    .card-body {
      padding: 40px;
    }

    .coverage-section h3 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #667eea;
      margin-bottom: 30px;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .coverage-item {
      display: flex;
      gap: 20px;
      padding: 25px;
      background: #f8f9fa;
      border-radius: 15px;
      margin-bottom: 20px;
      transition: all 0.3s ease;
    }

    .coverage-item:hover {
      background: #f0f4ff;
      transform: translateX(10px);
      box-shadow: 0 5px 20px rgba(102,126,234,0.1);
    }

    .coverage-icon {
      width: 70px;
      height: 70px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    .coverage-icon i {
      font-size: 2rem;
      color: white;
    }

    .coverage-icon.accident {
      background: linear-gradient(135deg, #ff6b6b, #ff8787);
    }

    .coverage-icon.theft {
      background: linear-gradient(135deg, #ffd93d, #ffd93d);
    }

    .coverage-icon.damage {
      background: linear-gradient(135deg, #667eea, #764ba2);
    }

    .coverage-icon.hospital {
      background: linear-gradient(135deg, #6bcf7f, #7bed9f);
    }

    .coverage-icon.third-party {
      background: linear-gradient(135deg, #ff9ff3, #feca57);
    }

    .coverage-info {
      flex: 1;
    }

    .coverage-info h4 {
      font-size: 1.3rem;
      font-weight: 600;
      color: #333;
      margin: 0 0 8px;
    }

    .coverage-info p {
      color: #666;
      margin: 0 0 10px;
      line-height: 1.5;
    }

    .coverage-amount {
      display: inline-block;
      padding: 6px 15px;
      background: #667eea;
      color: white;
      border-radius: 20px;
      font-size: 0.95rem;
      font-weight: 600;
    }

    .premium-summary {
      background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
      padding: 30px;
      border-radius: 15px;
      margin: 40px 0;
    }

    .summary-row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 0;
      border-bottom: 1px solid #dee2e6;
    }

    .summary-row:last-child {
      border-bottom: none;
    }

    .summary-row span {
      font-size: 1.1rem;
      color: #666;
    }

    .summary-row strong {
      font-size: 1.2rem;
      color: #333;
    }

    .plan-badge {
      padding: 8px 20px;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 20px;
      font-size: 1rem !important;
    }

    .summary-row.total {
      margin-top: 15px;
      padding-top: 25px;
      border-top: 3px solid #667eea;
    }

    .summary-row.total span {
      font-size: 1.3rem;
      font-weight: 600;
      color: #333;
    }

    .price {
      font-size: 2rem !important;
      font-weight: 800 !important;
      color: #4caf50 !important;
    }

    .benefits-section {
      margin-top: 40px;
    }

    .benefits-section h3 {
      font-size: 1.5rem;
      font-weight: 600;
      color: #667eea;
      margin-bottom: 25px;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .benefits-list {
      list-style: none;
      padding: 0;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
      gap: 15px;
    }

    .benefits-list li {
      padding: 15px 20px;
      background: #f8f9fa;
      border-radius: 10px;
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 1rem;
      color: #333;
      transition: all 0.3s ease;
    }

    .benefits-list li:hover {
      background: #e8f5e9;
      transform: translateX(5px);
    }

    .benefits-list i {
      color: #4caf50;
      font-size: 1.3rem;
    }

    .card-footer {
      padding: 30px 40px;
      background: #f8f9fa;
      text-align: center;
    }

    .proceed-btn {
      padding: 20px 50px;
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      color: white;
      border: none;
      border-radius: 50px;
      font-size: 1.2rem;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s ease;
      display: inline-flex;
      align-items: center;
      gap: 12px;
    }

    .proceed-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 15px 35px rgba(76,175,80,0.4);
    }

    @keyframes slideUp {
      from {
        opacity: 0;
        transform: translateY(30px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @media (max-width: 768px) {
      .card-header {
        flex-direction: column;
        text-align: center;
      }

      .coverage-item {
        flex-direction: column;
        text-align: center;
      }

      .coverage-icon {
        margin: 0 auto;
      }

      .benefits-list {
        grid-template-columns: 1fr;
      }
    }
  `]
})
export class InsuranceDetailsComponent implements OnInit {
  quoteId: number = 0;
  vehicleNumber: string = '';
  provider: string = '';
  plan: string = '';
  premium: number = 0;

  constructor(
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.quoteId = Number(params['quoteId']);
      this.vehicleNumber = params['vehicleNumber'] || '';
      this.provider = params['provider'] || '';
      this.plan = params['plan'] || '';
      this.premium = Number(params['premium']) || 0;
    });
  }

  proceedToKYC(): void {
    this.router.navigate(['/kyc-upload'], {
      queryParams: {
        quoteId: this.quoteId,
        vehicleNumber: this.vehicleNumber,
        provider: this.provider
      }
    });
  }
}