// src/app/components/vehicle-details/vehicle-details.component.ts
import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';
import { VehicleService } from '../../services/vehicle.service';
import { Vehicle } from '../../models/vehicle.model';

@Component({
  selector: 'app-vehicle-details',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="details-container">

      <!-- BACK BUTTON -->
      <div class="back-button" (click)="goBack()">
        <i class="bi bi-arrow-left"></i> Back to Home
      </div>

      <!-- MAIN BLOCK -->
      <div *ngIf="vehicle as v; else loadingOrError">
        <div class="details-card">

          <!-- HEADER -->
          <div class="card-header">
            <div class="vehicle-icon">
              <i class="bi bi-bicycle"></i>
            </div>

            <div>
              <h2>Vehicle Details</h2>
              <p class="vehicle-number">{{ v?.vehicleNumber }}</p>
            </div>
          </div>

          <!-- BODY -->
          <div class="card-body">

            <!-- BASIC INFORMATION -->
            <div class="info-section">
              <div class="section-title">
                <i class="bi bi-info-circle-fill"></i>
                <h3>Basic Information</h3>
              </div>

              <div class="info-grid">
                <div class="info-item">
                  <label>Vehicle Number</label>
                  <span class="value highlight">{{ v?.vehicleNumber }}</span>
                </div>

                <div class="info-item">
                  <label>Vehicle Year</label>
                  <span class="value">{{ v?.vehicleYear }}</span>
                </div>

                <div class="info-item">
                  <label>Owner ID</label>
                  <span class="value">{{ v?.userId }}</span>
                </div>
              </div>
            </div>

            <!-- COVERAGE INFORMATION -->
            <div class="info-section">
              <div class="section-title">
                <i class="bi bi-shield-fill-check"></i>
                <h3>Coverage Information</h3>
              </div>

              <div class="info-grid">

                <div class="info-item">
                  <label>Coverage Type</label>
                  <span class="value badge"
                        [ngClass]="{
                          'comprehensive': v?.coverageType === 'Comprehensive',
                          'third-party': v?.coverageType === 'Third Party'
                        }">
                    {{ v?.coverageType }}
                  </span>
                </div>

                <div class="info-item">
                  <label>Coverage Amount</label>
                  <span class="value price">₹{{ v?.coverageAmount }}</span>
                </div>

                <div class="info-item">
                  <label>Coverage Deductibles</label>
                  <span class="value price">₹{{ v?.coverageDeductibles }}</span>
                </div>

              </div>
            </div>

            <!-- DRIVING RECORD -->
            <div class="info-section">
              <div class="section-title">
                <i class="bi bi-exclamation-triangle-fill"></i>
                <h3>Driving Record</h3>
              </div>

              <div class="info-grid">

                <div class="info-item">
                  <label>Number of Accidents</label>
                  <span class="value"
                        [class.warning]="(v?.noOfDrivingAccidents ?? 0) > 0">
                    <i class="bi bi-car-front-fill"></i>
                    {{ v?.noOfDrivingAccidents }}
                  </span>
                </div>

                <div class="info-item">
                  <label>Number of Violations</label>
                  <span class="value"
                        [class.warning]="(v?.noOfDrivingViolations ?? 0) > 0">
                    <i class="bi bi-exclamation-octagon-fill"></i>
                    {{ v?.noOfDrivingViolations }}
                  </span>
                </div>

              </div>
            </div>

          </div>

          <!-- FOOTER BUTTONS -->
          <div class="card-footer">
            <button class="action-btn edit-btn" (click)="editVehicle()">
              <i class="bi bi-pencil-square"></i>
              Edit Vehicle Information
            </button>

            <button class="action-btn quote-btn" (click)="getQuotes()">
              <i class="bi bi-calculator-fill"></i>
              Get Price / Insurance
            </button>
          </div>

        </div>
      </div>

      <!-- LOADING / ERROR -->
      <ng-template #loadingOrError>

        <div *ngIf="loading" class="loading-container">
          <div class="spinner-border"></div>
          <p>Loading vehicle details...</p>
        </div>

        <div *ngIf="errorMessage && !loading" class="error-container">
          <i class="bi bi-exclamation-circle-fill"></i>
          <h3>Error Loading Vehicle</h3>
          <p>{{ errorMessage }}</p>
          <button class="back-btn" (click)="goBack()">Go Back</button>
        </div>

      </ng-template>

    </div>
  `,
  styles: [`
    /* Background */
    .details-container {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 30px;
      background: linear-gradient(135deg, #d7eeff, #ffffff);
      animation: fadeIn 0.8s ease-in-out;
    }

    /* Animation */
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    /* Card */
    .details-card {
      width: 80%;
      max-width: 850px;
      background: #fff;
      border-radius: 18px;
      padding: 25px;
      box-shadow: 0 6px 20px rgba(0,0,0,0.15);
      animation: fadeIn 1s ease-in-out;
      margin-top: 20px;
    }

    .card-header {
      display: flex;
      align-items: center;
      gap: 15px;
    }

    .vehicle-icon i {
      font-size: 40px;
      color: #1976d2;
    }

    .vehicle-number {
      font-weight: bold;
      color: #444;
      margin-top: -8px;
    }

    .info-section {
      margin-top: 25px;
    }

    .section-title {
      display: flex;
      align-items: center;
      gap: 10px;
      margin-bottom: 10px;
    }

    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 15px;
    }

    .info-item label {
      display: block;
      font-size: 14px;
      color: #666;
    }

    .value {
      font-size: 16px;
      font-weight: 600;
      color: #000;
    }

    .badge {
      padding: 5px 10px;
      border-radius: 6px;
      color: white;
    }

    .comprehensive { background: #2e7d32; }
    .third-party { background: #f57c00; }

    .warning { color: #d32f2f; }

    .price { color: #1976d2; }

    .card-footer {
      margin-top: 25px;
      display: flex;
      gap: 15px;
    }

    .action-btn {
      padding: 12px 18px;
      border-radius: 10px;
      border: none;
      cursor: pointer;
      color: white;
      font-weight: 600;
      transition: 0.3s;
    }

    .edit-btn { background: #0288d1; }
    .edit-btn:hover { background: #015c8b; }

    .quote-btn { background: #2e7d32; }
    .quote-btn:hover { background: #1b5e20; }

    .back-button {
      cursor: pointer;
      align-self: flex-start;
      font-size: 16px;
      font-weight: 500;
      color: #1976d2;
      margin-bottom: 10px;
    }
  `]
})
export class VehicleDetailsComponent implements OnInit {
  vehicle: Vehicle | null = null;
  loading = false;
  errorMessage = '';

  constructor(
    private vehicleService: VehicleService,
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const vehicleNumber = params['vehicleNumber'];
      if (vehicleNumber) this.loadVehicleDetails(vehicleNumber);
      else this.errorMessage = 'No vehicle number provided';
    });
  }

  loadVehicleDetails(vehicleNumber: string): void {
    this.loading = true;
    this.vehicleService.getVehicleByNumber(vehicleNumber).subscribe({
      next: data => {
        this.vehicle = data;
        this.loading = false;
      },
      error: () => {
        this.errorMessage = 'Failed to load vehicle details.';
        this.loading = false;
      }
    });
  }

  editVehicle(): void {
    if (!this.vehicle) return;
    this.router.navigate(['/vehicle-form'], {
      queryParams: {
        vehicleNumber: this.vehicle.vehicleNumber,
        userId: this.vehicle.userId,
        update: 'true'
      }
    });
  }

  getQuotes(): void {
    if (!this.vehicle) return;
    this.router.navigate(['/quotes'], {
      queryParams: {
        vehicleNumber: this.vehicle.vehicleNumber,
        userId: this.vehicle.userId
      }
    });
  }

  goBack(): void {
    this.router.navigate(['/']);
  }
}
