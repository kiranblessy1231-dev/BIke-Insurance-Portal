import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-application-success',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="success-container">
      <div class="success-card">
        <div class="success-animation">
          <div class="checkmark-circle">
            <i class="bi bi-check-lg"></i>
          </div>
        </div>

        <h1>Application Submitted Successfully!</h1>
        <p class="success-message">
          Congratulations! Your insurance application has been received and is now under review.
        </p>

        <div class="details-box">
          <div class="detail-row">
            <i class="bi bi-car-front-fill"></i>
            <div>
              <label>Vehicle Number</label>
              <strong>{{ vehicleNumber }}</strong>
            </div>
          </div>

          <div class="detail-row">
            <i class="bi bi-file-earmark-check-fill"></i>
            <div>
              <label>Application ID</label>
              <strong>#{{ applicationId || quoteId }}</strong>
            </div>
          </div>

          <div class="detail-row">
            <i class="bi bi-building"></i>
            <div>
              <label>Insurance Provider</label>
              <strong>{{ provider }}</strong>
            </div>
          </div>

          <div class="detail-row">
            <i class="bi bi-check-circle-fill"></i>
            <div>
              <label>Status</label>
              <strong class="status-badge success">Successfully Approved</strong>
            </div>
          </div>
        </div>

        <div class="timeline-section">
          <h3><i class="bi bi-list-check"></i> What Happens Next?</h3>
          <div class="timeline">
            <div class="timeline-item">
              <div class="timeline-icon">1</div>
              <div class="timeline-content">
                <h4>Document Verification</h4>
                <p>Our team will review your documents within 24-48 hours</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="timeline-icon">2</div>
              <div class="timeline-content">
                <h4>Email Confirmation</h4>
                <p>You'll receive confirmation once verified</p>
              </div>
            </div>
            <div class="timeline-item">
              <div class="timeline-icon">3</div>
              <div class="timeline-content">
                <h4>Policy Activation</h4>
                <p>Policy documents sent to your registered email</p>
              </div>
            </div>
          </div>
        </div>

        <div class="contact-info">
          <div class="contact-item">
            <i class="bi bi-envelope-fill"></i>
            <span>support&#64;bikeinsurance.com</span>
          </div>
          <div class="contact-item">
            <i class="bi bi-telephone-fill"></i>
            <span>1800-123-4567</span>
          </div>
        </div>

        <div class="action-buttons">
          <button class="btn home-btn" (click)="goHome()">
            <i class="bi bi-house-fill"></i>
            Back to Home
          </button>
          <button class="btn print-btn" (click)="printDetails()">
            <i class="bi bi-printer-fill"></i>
            Print Details
          </button>
        </div>
      </div>

      <!-- Confetti Animation -->
      <div class="confetti">
        <div class="confetti-piece" *ngFor="let i of confettiArray"></div>
      </div>
    </div>
  `,
  styles: [`
    .success-container {
      min-height: 100vh;
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      padding: 40px 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      overflow: hidden;
    }

    .success-card {
      max-width: 800px;
      width: 100%;
      background: white;
      border-radius: 25px;
      box-shadow: 0 25px 70px rgba(0,0,0,0.4);
      padding: 60px 50px;
      text-align: center;
      animation: zoomIn 0.8s ease;
      position: relative;
      z-index: 2;
    }

    @keyframes zoomIn {
      from { opacity: 0; transform: scale(0.8); }
      to { opacity: 1; transform: scale(1); }
    }

    .success-animation {
      margin-bottom: 35px;
    }

    .checkmark-circle {
      width: 140px;
      height: 140px;
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      margin: 0 auto;
      animation: bounce 1.2s ease;
      box-shadow: 0 10px 40px rgba(76,175,80,0.5);
    }

    @keyframes bounce {
      0%, 20%, 50%, 80%, 100% { transform: translateY(0); }
      40% { transform: translateY(-30px); }
      60% { transform: translateY(-15px); }
    }

    .checkmark-circle i {
      font-size: 5rem;
      color: white;
      animation: checkScale 0.5s ease 0.5s both;
    }

    @keyframes checkScale {
      0% { transform: scale(0); }
      100% { transform: scale(1); }
    }

    h1 {
      font-size: 2.5rem;
      font-weight: 800;
      color: #333;
      margin-bottom: 20px;
    }

    .success-message {
      font-size: 1.2rem;
      color: #666;
      margin-bottom: 45px;
      line-height: 1.7;
    }

    .details-box {
      background: #f8f9fa;
      padding: 35px;
      border-radius: 20px;
      margin-bottom: 45px;
      display: grid;
      gap: 25px;
    }

    .detail-row {
      display: flex;
      align-items: center;
      gap: 20px;
      text-align: left;
    }

    .detail-row i {
      font-size: 2.8rem;
      color: #4caf50;
    }

    .detail-row label {
      display: block;
      font-size: 0.95rem;
      color: #999;
      margin-bottom: 5px;
    }

    .detail-row strong {
      font-size: 1.4rem;
      color: #333;
    }

    .status-badge {
      display: inline-block;
      padding: 8px 20px;
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      color: white;
      border-radius: 50px;
      font-size: 1.1rem !important;
      font-weight: 600;
    }
    
    .status-badge.success {
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      box-shadow: 0 4px 15px rgba(76, 175, 80, 0.3);
    }

    .timeline-section {
      text-align: left;
      margin-bottom: 45px;
    }

    .timeline-section h3 {
      font-size: 1.6rem;
      font-weight: 700;
      color: #4caf50;
      margin-bottom: 30px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .timeline {
      display: grid;
      gap: 25px;
    }

    .timeline-item {
      display: flex;
      gap: 20px;
      align-items: flex-start;
    }

    .timeline-icon {
      width: 50px;
      height: 50px;
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      color: white;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 1.5rem;
      font-weight: 700;
      flex-shrink: 0;
      box-shadow: 0 5px 20px rgba(76,175,80,0.3);
    }

    .timeline-content h4 {
      font-size: 1.2rem;
      font-weight: 700;
      color: #333;
      margin: 0 0 8px;
    }

    .timeline-content p {
      color: #666;
      margin: 0;
      line-height: 1.6;
    }

    .contact-info {

      background: #e8f5e9;
      padding: 25px;
      border-radius: 15px;
      margin-bottom: 40px;
      display: flex;
      justify-content: center;
      gap: 40px;
      flex-wrap: wrap;
    }

    .contact-item {
      display: flex;
      align-items: center;
      gap: 10px;
      font-size: 1.1rem;
      color: #2e7d32;
      font-weight: 600;
    }

    .contact-item i {
      font-size: 1.5rem;
    }

    .action-buttons {
      display: flex;
      gap: 20px;
      justify-content: center;
      flex-wrap: wrap;
    }

    .btn {
      padding: 18px 40px;
      border: none;
      border-radius: 50px;
      font-size: 1.1rem;
      font-weight: 700;
      cursor: pointer;
      transition: all 0.3s ease;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .home-btn {
      background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
      color: white;
      box-shadow: 0 5px 20px rgba(76,175,80,0.3);
    }

    .home-btn:hover {
      transform: translateY(-3px);
      box-shadow: 0 10px 30px rgba(76,175,80,0.5);
    }

    .print-btn {
      background: white;
      color: #4caf50;
      border: 3px solid #4caf50;
    }

    .print-btn:hover {
      background: #4caf50;
      color: white;
      transform: translateY(-3px);
    }

    .confetti {
      position: absolute;
      width: 100%;
      height: 100%;
      overflow: hidden;
      z-index: 1;
    }

    .confetti-piece {
      position: absolute;
      width: 12px;
      height: 12px;
      background: #f0f;
      top: -20px;
      opacity: 0;
      animation: confetti-fall 4s linear infinite;
    }

    .confetti-piece:nth-child(1) { left: 10%; animation-delay: 0s; background: #ff6b6b; }
    .confetti-piece:nth-child(2) { left: 20%; animation-delay: 0.5s; background: #4caf50; }
    .confetti-piece:nth-child(3) { left: 30%; animation-delay: 1s; background: #ffd93d; }
    .confetti-piece:nth-child(4) { left: 40%; animation-delay: 1.5s; background: #667eea; }
    .confetti-piece:nth-child(5) { left: 50%; animation-delay: 2s; background: #ff9ff3; }
    .confetti-piece:nth-child(6) { left: 60%; animation-delay: 0.3s; background: #feca57; }
    .confetti-piece:nth-child(7) { left: 70%; animation-delay: 0.8s; background: #48dbfb; }
    .confetti-piece:nth-child(8) { left: 80%; animation-delay: 1.3s; background: #ff6348; }
    .confetti-piece:nth-child(9) { left: 90%; animation-delay: 1.8s; background: #1dd1a1; }
    .confetti-piece:nth-child(10) { left: 95%; animation-delay: 2.3s; background: #5f27cd; }

    @keyframes confetti-fall {
      0% { top: -20px; opacity: 1; transform: rotate(0deg); }
      100% { top: 110%; opacity: 0.7; transform: rotate(720deg); }
    }

    @media (max-width: 768px) {
      .success-card {
        padding: 40px 25px;
      }

      h1 {
        font-size: 2rem;
      }

      .action-buttons {
        flex-direction: column;
      }

      .btn {
        width: 100%;
        justify-content: center;
      }

      .contact-info {
        flex-direction: column;
        gap: 15px;
      }
    }
  `]
})
export class ApplicationSuccessComponent implements OnInit {
  quoteId: number = 0;
  applicationId: number = 0;
  vehicleNumber: string = '';
  provider: string = '';
  confettiArray = Array(10).fill(0);

  constructor(
    private router: Router,
    private route: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.quoteId = Number(params['quoteId']) || 0;
      this.applicationId = Number(params['applicationId']) || 0;
      this.vehicleNumber = params['vehicleNumber'] || '';
      this.provider = params['provider'] || 'N/A';
      
      console.log('Success page loaded:', { 
        quoteId: this.quoteId, 
        applicationId: this.applicationId,
        vehicleNumber: this.vehicleNumber, 
        provider: this.provider 
      });
    });
  }

  goHome(): void {
    this.router.navigate(['/']);
  }

  printDetails(): void {
    window.print();
  }
}