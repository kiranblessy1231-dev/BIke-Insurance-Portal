import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-role-selection',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container mt-5">
      <div class="card mx-auto" style="max-width: 500px;">
        <div class="card-header bg-primary text-white">
          <h3 class="mb-0">Welcome to Bike Insurance Portal</h3>
        </div>
        <div class="card-body">
          <h5 class="card-title mb-4">Select Your Role</h5>
          <div class="mb-3">
            <label class="form-label">I am a:</label>
            <select [(ngModel)]="role" class="form-select" (change)="onRoleChange()">
              <option value="">-- Please Select --</option>
              <option value="user">User</option>
              <option value="admin">Admin</option>
            </select>
          </div>
          <button 
            class="btn btn-primary w-100" 
            [disabled]="!role"
            (click)="continue()">
            Continue
          </button>
        </div>
      </div>
    </div>
  `
})
export class RoleSelectionComponent {
  role: string = '';

  constructor(private router: Router) {}

  onRoleChange(): void {
    // Reset on role change
  }

  continue(): void {
    if (this.role === 'admin') {
      this.router.navigate(['/admin-login']);
    } else if (this.role === 'user') {
      this.router.navigate(['/vehicle-check']);
    }
  }
}