import { AdminApplication } from './admin-application.model';
import { InsuranceQuote } from './insurance-quote.model';

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data?: T;
  userId?: string;
  vehicleNumber?: string;
  quoteId?: number;
  kycId?: number;
  quotes?: InsuranceQuote[];
  applications?: AdminApplication[];
}
