export interface InsuranceQuote {
  providerName: string;
  basic: number;
  premium: number;
}

export interface InsuranceApplication {
  userId: string;
  vehicleId: number;
  selectedProvider: string;
  selectedPlan: string;
  premiumAmount: number;
}