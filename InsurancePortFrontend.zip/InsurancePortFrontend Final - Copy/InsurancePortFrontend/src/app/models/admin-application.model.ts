export interface AdminApplication {
  id: number;
  userName: string;
  userEmail: string;
  vehicleNumber: string;
  selectedProvider: string;
  selectedPlan: string;
  premiumAmount: number;
  kycStatus: string;
  appliedAt: string;
}