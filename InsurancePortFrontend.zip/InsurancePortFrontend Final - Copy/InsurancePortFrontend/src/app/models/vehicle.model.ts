export interface Vehicle {
  id?: number;
  userId: string;
  vehicleNumber: string;
  vehicleYear: number;
  coverageType?: string;
  coverageAmount?: number;
  coverageDeductibles?: number;
  noOfDrivingAccidents?: number;
  noOfDrivingViolations?: number;
  createdAt?: string | Date;
}