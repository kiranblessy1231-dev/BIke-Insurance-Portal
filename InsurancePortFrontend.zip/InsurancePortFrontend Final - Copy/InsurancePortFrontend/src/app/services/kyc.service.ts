// src/app/services/kyc.service.ts
import { Injectable } from '@angular/core';
import { HttpClient, HttpEvent } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class KycService {
  private apiUrl = 'http://localhost:8080/api/kyc';

  constructor(private http: HttpClient) {}

  uploadKyc(
    quoteId: number,
    files: { drivingLicense: File; rc: File; aadhar: File }
  ): Observable<HttpEvent<any>> {
    const formData = new FormData();
    formData.append('drivingLicense', files.drivingLicense);
    formData.append('rc', files.rc);
    formData.append('aadhar', files.aadhar);

    return this.http.post(`${this.apiUrl}/upload/${quoteId}`, formData, {
      reportProgress: true,
      observe: 'events'
    });
  }
}