import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { AdminApplication } from '../models/admin-application.model';
import { ApiResponse } from '../models/api-response.model';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
  private apiUrl = 'http://localhost:8080/api/admin';

  constructor(private http: HttpClient) {}

  getAllApplications(): Observable<AdminApplication[]> {
    return this.http.get<ApiResponse<AdminApplication[]>>(`${this.apiUrl}/allApplications`)
      .pipe(map(response => {
        if (response.success && response.applications) {
          return response.applications;
        }
        return [];
      }));
  }
}