import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly ADMIN_ID = 'Admin05';
  private readonly ADMIN_PASSWORD = '123456';
  private readonly ADMIN_KEY = 'adminLoggedIn';

  login(role: string, adminId?: string, password?: string): boolean {
    if (role === 'admin') {
      if (adminId === this.ADMIN_ID && password === this.ADMIN_PASSWORD) {
        sessionStorage.setItem(this.ADMIN_KEY, 'true');
        return true;
      }
      return false;
    }
    return true; // Users don't need authentication
  }

  isAdminLoggedIn(): boolean {
    return sessionStorage.getItem(this.ADMIN_KEY) === 'true';
  }

  logout(): void {
    sessionStorage.removeItem(this.ADMIN_KEY);
  }
}

