// ...existing code...
import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private apiUrl = 'http://localhost:8080/api/user';

  constructor(private http: HttpClient) {}

  saveUser(user: User): Observable<User> {
    // Validate before sending
    const userPayload = {
      name: user.name.trim(),
      email: user.email.trim().toLowerCase(),
      phone: user.phone.trim()
    };

    console.log('📤 Sending user data to backend:', userPayload);

    return this.http.post<any>(`${this.apiUrl}/save`, userPayload)
      .pipe(
        map(response => {
          console.log('📥 Backend response:', response);

          if (response?.success && response.userId != null) {
            // return the saved user with string userId
            return { ...user, userId: String(response.userId) } as User;
          }

          throw new Error(response?.message || 'Failed to save user');
        }),
        catchError((error: HttpErrorResponse) => {
          console.error('❌ User save error:', error);

          let errorMessage = 'Failed to save user details';

          if (error.status === 400) {
            if (error.error?.message) {
              errorMessage = error.error.message;
            } else if (typeof error.error === 'string') {
              errorMessage = error.error;
            } else {
              errorMessage = 'Invalid user data. Please check all fields.';
            }
          } else if (error.status === 0) {
            errorMessage = 'Cannot connect to server. Please ensure backend is running on port 8080.';
          } else if (error.status === 500) {
            errorMessage = 'Server error. Please try again later.';
          }

          return throwError(() => new Error(errorMessage));
        })
      );
  }

  getUserByUserId(userId: string): Observable<User> {
    return this.http.get<any>(`${this.apiUrl}/show/${userId}`)
      .pipe(
        map(response => {
          if (response?.success) {
            return {
              userId: String(response.userId ?? response.data?.userId),
              name: response.name || response.data?.name || '',
              email: response.email || response.data?.email || '',
              phone: response.phone || response.data?.phone || ''
            } as User;
          }
          throw new Error(response?.message || 'User not found');
        }),
        catchError((error: HttpErrorResponse) => {
          console.error('❌ User fetch error:', error);
          return throwError(() => new Error('User not found'));
        })
      );
  }

  updateUser(userId: string, updates: Partial<User>): Observable<User> {
    return this.http.put<any>(`${this.apiUrl}/update/${userId}`, updates)
      .pipe(
        map(response => {
          if (response?.success) {
            return { userId, ...updates } as User;
          }
          throw new Error(response?.message || 'Failed to update user');
        }),
        catchError((error: HttpErrorResponse) => {
          console.error('❌ User update error:', error);
          return throwError(() => new Error('Failed to update user'));
        })
      );
  }
}
// ...existing code...